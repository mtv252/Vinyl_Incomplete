package com.example.mymusic;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toolbar;

import java.util.ArrayList;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        Resources res = getResources();

        ArrayList<Album> albums = new ArrayList<>();
        albums.add(new Album("Owls", "Owls", R.drawable.owls));
        albums.add(new Album("Xenia Rubinos", "Black Terry Cat", R.drawable.black_terry_cat));
        albums.add(new Album("Palm", "Rock Island", R.drawable.rock_island));
        albums.add(new Album("J Dilla", "Donuts", R.drawable.donuts));
        albums.add(new Album("Owls", "Owls", R.drawable.owls));
        albums.add(new Album("Xenia Rubinos", "Black Terry Cat", R.drawable.black_terry_cat));


        AlbumAdapter itemsAdapter = new AlbumAdapter(this, albums);

        final GridView gridView = (GridView) findViewById(R.id.album_library);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this, NowPlayingActivity.class);
                Album instance = (Album) gridView.getItemAtPosition(i);
                intent.putExtra("Album", instance);
                startActivity(intent);
            }
        });
        gridView.setAdapter(itemsAdapter);
    }

}