package com.example.mymusic;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class NowPlayingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.now_playing_activity);

        RelativeLayout wholeView = (RelativeLayout) findViewById(R.id.now_playing_view);

        if(getIntent().getExtras() != null) {
            Album selection = (Album) getIntent().getSerializableExtra("Album");

            ImageView albumArt = (ImageView) findViewById(R.id.now_playing_art);
            albumArt.setImageResource(selection.getAlbumArt());

            TextView artistName = (TextView) findViewById(R.id.now_playing_artist);
            artistName.setText(selection.getArtistName() + " -");

            TextView albumName =  (TextView) findViewById(R.id.now_playing_name);
            albumName.setText(selection.getAlbumName());
        }


    }
}